package it.aps.whistler.ui.text;

public enum Page {
	EXIT_CONSOLE,
	WHISTLER_CONSOLE,
	SIGNUP_CONSOLE,
	LOGIN_CONSOLE,
	HOME_CONSOLE
	}
