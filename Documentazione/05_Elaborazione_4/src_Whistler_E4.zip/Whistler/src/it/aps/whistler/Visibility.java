package it.aps.whistler;

public enum Visibility{
	PUBLIC,
	PRIVATE
}